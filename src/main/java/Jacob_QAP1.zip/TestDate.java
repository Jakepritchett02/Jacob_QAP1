public class TestDate {
    public static void  main (String[] args){
        Date date1 = new Date(11, 6, 2022 );
        Date date2 = new Date(11, 1, 2002);
        System.out.println(date1);
        System.out.println(date2);
    }
}
